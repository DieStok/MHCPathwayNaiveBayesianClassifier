##Dieter Stoker
##started 28-02-2017
##Transcription factor binding
#Goal: checks genes conserved across 29 mammals for conserved TFBSs that are significantly overrepresented
#in the MHC genes (tested with Fisher's exact p with Benjamini-Hochberg correction for multiple testing)
#Assigns a score (sample odds ratio estimate from Fisher's exact p/corrected p-value Fisher's exact p)
#for each informative TFBS. Cumulative scores are calculated for each of the conserved genes.


##Install required libraries and load the data

loadLibraryAndData <- function(reloadFromSource = FALSE) {
  
  if(!require("plyr")) install.packages("plyr")
  if(!require("ggplot2")) 
  
  
}

install.packages("ggplot2")
install.packages("reshape2")

library("plyr")
library("ggplot2")
library("reshape2")

options(stringsAsFactors = FALSE)
?save
##load Data

transcriptionFactorTableOneLine = read.table(file = "~/Documents/Project/Data/Data/transcription_fact_binding_sites/29mammals_unique_tfbs_per_gene_one_line.txt")
head(transcriptionFactorTableOneLine)
colnames(transcriptionFactorTableOneLine) = c("EnsemblId","transcriptionFactorBindingSites")

transcriptionFactorTableMultipleLines = read.table(file = "~/Documents/Project/Data/Data/transcription_fact_binding_sites/29mammals_unique_tfbs_per_gene_per_line.txt")
head(transcriptionFactorTableMultipleLines)
colnames(transcriptionFactorTableMultipleLines) = c("EnsemblId","transcriptionFactorBindingSites")
tail(transcriptionFactorTableMultipleLines)

positiveMHCGenes = read.csv(file="~/Documents/Project/MHCGenes/Lists/PositiveList_2.csv", header = TRUE)
head(positiveMHCGenes)
names(positiveMHCGenes)[7] = "EnsemblId"

#select relevant MHC genes from large dataset ##NOTE: not all are present in this dataset

relevantGenes <- transcriptionFactorTableMultipleLines[transcriptionFactorTableMultipleLines$EnsemblId %in% positiveMHCGenes$EnsemblId,]
head(relevantGenes)

#get the TFBS in count values for MHC Genes
positiveSetPresenceAmountTFBSDf = count(relevantGenes$transcriptionFactorBindingSites)
names(positiveSetPresenceAmountTFBSDf) = c("TFBS","Counts")
positiveSetPresenceAmountTFBSDf[,1] <- as.character(positiveSetPresenceAmountTFBSDf[,1])

#get the TFBS in count values for all genes
totalSetPresenceAmountTFBSDf = count(transcriptionFactorTableMultipleLines$transcriptionFactorBindingSites)
names(totalSetPresenceAmountTFBSDf) = c("TFBS","Counts")
head(totalSetPresenceAmountTFBSDf)
totalCountsFullSet = sum(totalSetPresenceAmountTFBSDf$Counts)
totalSetPresenceAmountTFBSDf[,1] = as.character(totalSetPresenceAmountTFBSDf[,1])

#calculate per transcription factor the genome odds that a random gene has that TFBS

genomeOdds <- apply(totalSetPresenceAmountTFBSDf, FUN = function(x) {
  as.numeric(x[2])/totalCountsFullSet
  }, MARGIN = 1)
names(genomeOdds) <- totalSetPresenceAmountTFBSDf$TFBS

#calculate per transcription factor the MHC odds that a gene has that TFBS
totalCountsMHCSet <- sum(positiveSetPresenceAmountTFBSDf$Counts)
MHCOdds <- apply(positiveSetPresenceAmountTFBSDf, FUN = function(x) {
  as.numeric(x[2])/totalCountsMHCSet
}, MARGIN = 1)
names(MHCOdds) <- positiveSetPresenceAmountTFBSDf$TFBS


##analyse with Fisher's exact p.

#extract relevant TFBS from whole genome
relevantTotalSetTFBS <- totalSetPresenceAmountTFBSDf[totalSetPresenceAmountTFBSDf$TFBS %in% positiveSetPresenceAmountTFBSDf$TFBS,]
str(relevantTotalSetTFBS)
rownames(relevantTotalSetTFBS) <- seq(1:nrow(relevantTotalSetTFBS))

#a = counts appeareance specific TFBS in whole genome
#b = total TFBS in whole genome
#c= counts, appearance specific TFBS in MHC set
#d = counts, total TFBS in MHC set
#one-tailed, either it is larger in MHC or it is equal, you do not expect it to be...less, right?
fishermatrixTFBS1 = matrix(c(positiveSetPresenceAmountTFBSDf$Counts[1], totalCountsMHCSet-positiveSetPresenceAmountTFBSDf$Counts[1], relevantTotalSetTFBS$Counts[1], totalCountsFullSet-relevantTotalSetTFBS$Counts[1]), nrow = 2)
fisher.test(fishermatrixTFBS1)
?fisher.test
#do the above in a function, for all relevant TFBS

computeFisherstest = function(wholeGenomeTFBSCountData, positiveSetTFBSCountData) {
  
  relevantWholeGenome <- wholeGenomeTFBSCountData[wholeGenomeTFBSCountData$TFBS %in% positiveSetTFBSCountData$TFBS,] 
  totalCountsWholeGenome <- sum(wholeGenomeTFBSCountData$Counts)
  totalCountsMHCGenes <- sum(positiveSetTFBSCountData$Counts)
  
  listMatrices <- list()
  fisherDataFrame <- data.frame(TFBS = character(),
                                pValue=numeric(),
                                sampleEstimate=numeric(),
                                lowerConfidenceInterval=numeric(),
                                upperConfidenceInterval=numeric())
  
  for(bindingSites in 1:nrow(positiveSetTFBSCountData)) {
    
    fisherMatrix <- matrix(c(positiveSetTFBSCountData$Counts[bindingSites],
                             totalCountsMHCGenes - positiveSetTFBSCountData$Counts[bindingSites],
                             relevantWholeGenome$Counts[bindingSites],
                             totalCountsWholeGenome - relevantWholeGenome$Counts[bindingSites]),
                           nrow = 2,
                           dimnames = list(TFBS = c(relevantWholeGenome$TFBS[bindingSites], "TotalTFBS"),
                                           Set = c("Positive set", "Whole genome")))
    fisherTestResult <- fisher.test(fisherMatrix)
    pValue = fisherTestResult["p.value"]
    lowerConfInt <- unlist(fisherTestResult["conf.int"])[1]
    upperConfInt <- unlist(fisherTestResult["conf.int"])[2]
    sampleEst <- fisherTestResult["estimate"]
    
    listMatrices <- append(listMatrices,fisherMatrix)
    addVector <- c(as.character(relevantWholeGenome$TFBS[bindingSites]),
                   pValue,
                   sampleEst,
                   lowerConfInt,
                   upperConfInt)
    names(addVector) <- c("TFBS", "pValue", "sampleEstimate",
                          "lowerConfidenceInterval", "upperConfidenceInterval")
    fisherDataFrame <- rbind(fisherDataFrame, addVector, make.row.names = FALSE)
    
  }
  
  fisherDataFrame$qValue <- p.adjust(fisherDataFrame$pValue, method="BH")
  return(fisherDataFrame)
  
  
  
}

fisherTests <- computeFisherstest(totalSetPresenceAmountTFBSDf,positiveSetPresenceAmountTFBSDf)



informativeTranscriptionFactors <- fisherTests[fisherTests$qValue < 0.10,]
informativeTranscriptionFactors[order(informativeTranscriptionFactors$qValue),]
rownames(informativeTranscriptionFactors) = seq(1:nrow(informativeTranscriptionFactors))
informativeTranscriptionFactors$score <- log(informativeTranscriptionFactors$sampleEstimate / informativeTranscriptionFactors$qValue)


##Dus: nu heb ik TFBS die significant enriched zijn in MHC-genen. Check nu in het hele genoom
##welke genen deze TFBS ook hebben. Maak een score:
#elke TFBS die ze hebben voegt toe, gewogen aan de sample estimate * qValue

#test subset whole Genome
testSubsetWG <- transcriptionFactorTableOneLine[1:50,]
head(testSubsetWG)
?subset
ncol(testSubsetWG)


pmatch(c("", "ab", "ab"), c("abc", "ab"), dup = FALSE)
pmatch(c("", "ab", "ab"), c("abc", "ab"), dup = TRUE)
pmatch("STAT_9", "MFX | BRK | STAT_9")

testSubsetWG[1,][2] %in% "STAT_9"
flerp <- unlist(strsplit(as.character(testSubsetWG[1,][2]), split = "|", fixed = TRUE))
"STAT_9" %in% flerp
c("STAT_9","HORPIE") %in% flerp
c("STAT_9","HORPIE","Pitx3") %in% flerp
?strsplit

braam <- scoresOverRows(testSubsetWG, informativeTranscriptionFactors)
head(braam)
tail(braam)
braam[200:300,]








head(transcriptionFactorTableOneLine)
  
  
  scoresOverRows <- function(wholeGenomeDataOneLine, informativeTFs) {
    
 
    scoreCompendium <- vector()
    dataFrameResults <- data.frame()
    for(rows in 1:nrow(wholeGenomeDataOneLine)) {
      
      currentRow <- wholeGenomeDataOneLine[rows,]
      currentRowTFs <- currentRow[2]
      characterVectorTFs <- unlist(strsplit(as.character(currentRowTFs), split = "|", fixed = TRUE))
      logicalPresence <- informativeTFs$TFBS %in% characterVectorTFs
      currentRowEnsemblId <- currentRow["EnsemblId"]
      
      for(bindingSites in 1:length(logicalPresence)) {
        
        if(logicalPresence[bindingSites] == TRUE) {
          
          valueToAdd <- informativeTFs$score[bindingSites]
          
          
        } else if (logicalPresence[bindingSites] == FALSE) {
          
          valueToAdd <- 0
          
        }
        
        scoreCompendium <- append(scoreCompendium,valueToAdd)
        names(scoreCompendium)[bindingSites] <-  informativeTFs$TFBS[bindingSites]
        
      }
      dataFrameResults <- rbind(dataFrameResults, scoreCompendium)
      rownames(dataFrameResults) <- c(head(rownames(dataFrameResults),-1),currentRow["EnsemblId"])
      scoreCompendium <- vector()
      #print(nrow(dataFrameResults))
      
    }
    colnames(dataFrameResults) <- paste("Score for TFBS", informativeTFs$TFBS)
    dataFrameResults$totalScore <- rowSums(dataFrameResults)
    return(dataFrameResults)
  }
  
#testOutput <- scoresOverRows(testSubsetWG, informativeTranscriptionFactors)  
#head(testOutput)  
#tail(testOutput)
#testOutput[order(testOutput$totalScore),]
 
  
allGenesScoredForTFBSPresence <-   scoresOverRows(transcriptionFactorTableOneLine,informativeTranscriptionFactors)
pipo <- allGenesScoredForTFBSPresence[order(allGenesScoredForTFBSPresence$totalScore, decreasing = TRUE),]
head(pipo)  
tail(pipo)
?order   
head(scoresOverRows(transcriptionFactorTableOneLine,informativeTranscriptionFactors))
sum(pipo$totalScore>0)

pizza = scoresOverRows(transcriptionFactorTableOneLine,informativeTranscriptionFactors)
  
  ?sapply
generateTFBSScores(transcriptionFactorTableOneLine,informativeTranscriptionFactors)





scoresOverRows <- function() {
  
  logicalPresence <- informativeTranscriptionFactors$TFBS %in% x[2]
  
  scoreCompendium <- vector()
  
  for(bindingSites in 1:length(logicalPresence)) {
    
    if(logicalPresence[bindingSites] == TRUE) {
      
      valueToAdd <- informativeTranscriptionFactors$sampleEstimate[bindingSites] * informativeTranscriptionFactors$qValue[bindingSites]
      
      
    } else if (logicalPresence[bindingSites] == FALSE) {
      
      valueToAdd <- 0
      
    }
    
    scoreCompendium <- append(scoreCompendium,valueToAdd)
    names(scoreCompendium)[bindingSites] <-  informativeTranscriptionFactors$TFBS[bindingSites]
    
  }
  
}

apply(transcriptionFactorTableOneLine,MARGIN=1,FUN=scoresOverRows)

















TeaTasting <-
  matrix(c(3, 1, 1, 3),
         nrow = 2,
         dimnames = list(Guess = c("Milk", "Tea"),
                         Truth = c("Milk", "Tea")))








ggplot(presenceAmountTFBSDf, aes(y=Counts, x=TFBS)) + geom_bar(stat="identity") +
  scale_x_discrete(breaks = presenceAmountTFBSDf$TFBS[presenceAmountTFBSDf$Counts>5], labels = presenceAmountTFBSDf$TFBS[presenceAmountTFBSDf$Counts>5]) +
  theme_bw() + theme(axis.text.x=element_text(angle=90, hjust=1, vjust = 1))

#random genes from large dataset
randomGenes <- transcriptionFactorTableOneLine[runif() %in% positiveMHCGenes$EnsemblId,]

runif(nrow(positiveMHCGenes),1,nrow(transcriptionFactorTableMultipleLines))
