##Dieter Stoker
##started 28-02-2017
##Transcription factor binding
#Goal: checks genes conserved across 29 mammals for conserved TFBSs that are significantly overrepresented
#in the MHC genes (tested with Fisher's exact p with Benjamini-Hochberg correction for multiple testing)
#Assigns a score (sample odds ratio estimate from Fisher's exact p/corrected p-value Fisher's exact p)
#for each informative TFBS. Cumulative scores are calculated for each of the conserved genes.
##'finished' 02-03-2016


##Install required libraries and load the data

loadLibraryAndData <- function(reloadFromSource = FALSE) {
  
  #load required libraries
  if(!require("plyr")) install.packages("plyr")
  if(!require("ggplot2")) install.packages("ggplot2")
  if(!require("reshape2")) install.packages("reshape2")
  if(!require("tcltk")) install.packages("tcltk")
  
  library("plyr")
  library("ggplot2")
  library("reshape2")
  library("tcltk")
  
  currentDir <- getwd()
  
  options(stringsAsFactors = FALSE)
  
  if(reloadFromSource == TRUE) {
  
  colNamesTFBSTables <- c("EnsemblId","TranscriptionFactorBindingSites")
  
  
  print("Choose the file that contains the conserved TFBS on one line")
  tFTableOneLine <- read.table(tk_choose.files(default = "~/Documents/Project/Programming/Transcription Factor Binding/29mammals_unique_tfbs_per_gene_one_line.txt",
                                               caption = "Choose the .txt file that contains the conserved TFBS on one line",
                                               multi = FALSE))
  colnames(tFTableOneLine) <- colNamesTFBSTables
  print(head(tFTableOneLine))
  
  
  tFTableMultipleLines <- read.table(tk_choose.files(default = "~/Documents/Project/Programming/Transcription Factor Binding/29mammals_unique_tfbs_per_gene_per_line.txt",
                                                     caption = "Choose the .txt file that contains the conserved TFBS on multiple lines",
                                                     multi = FALSE))
  colnames(tFTableMultipleLines) <- colNamesTFBSTables
  print(head(tFTableMultipleLines))
  
  MHCGeneTable <- read.csv(tk_choose.files(default = "~/Documents/Project/Programming/Transcription Factor Binding/PositiveList_2.csv",
                                           caption = "Choose the .csv file that contains the positive MHC gene set",
                                           multi = FALSE),header = TRUE)
  
  names(MHCGeneTable)[7] <- "EnsemblId"
  
  
  #save as .R data files
  
  saveRDS(tFTableOneLine, file = paste(currentDir, "/tFTableOneLine.rds",sep=""))
  saveRDS(tFTableMultipleLines, file = paste(currentDir, "/tFTableMultipleLines.rds",sep=""))
  saveRDS(MHCGeneTable, file = paste(currentDir, "/MHCGeneTable.rds",sep=""))
  
  } else if (reloadFromSource == FALSE) {
    
    tFTableOneLine <- readRDS(file = paste(currentDir, "/tFTableOneLine.rds", sep=""))
    tFTableMultipleLines <- readRDS(file = paste(currentDir, "/tFTableMultipleLines.rds", sep=""))
    MHCGeneTable <- readRDS(file = paste(currentDir, "/MHCGeneTable.rds", sep=""))
    
  }
  
  #______________________________
  
  amountPositiveSetInList <- sum(MHCGeneTable$EnsemblId %in% tFTableMultipleLines$EnsemblId)
  relevantTFBSDf <- tFTableMultipleLines[tFTableMultipleLines$EnsemblId %in% MHCGeneTable$EnsemblId,]
  print(paste("Amount of positive set genes in 29 mammals data set:", amountPositiveSetInList))
  print(head(relevantTFBSDf))
  
  #Count data TFBS for MHC gene set
  countDataNames <-c("TFBS","Counts")
  
  positiveSetTFBSCounts <- count(relevantTFBSDf$TranscriptionFactorBindingSites)
  names(positiveSetTFBSCounts) <- countDataNames
  
  totalCountsMHCSet <- sum(positiveSetTFBSCounts$Counts)
  
  #Count data for TFBS in all genes
  
  totalSetTFBSCounts = count(tFTableMultipleLines$TranscriptionFactorBindingSites)
  names(totalSetTFBSCounts) = countDataNames
  
  totalCountsFullSet = sum(totalSetTFBSCounts$Counts)
  
  #calculate the odds that a random gene in the full set has a certain TFBS
  
  genomeOdds <- apply(totalSetTFBSCounts, FUN = function(x) {
    as.numeric(x[2])/totalCountsFullSet
  }, MARGIN = 1)
  names(genomeOdds) <- totalSetTFBSCounts$TFBS
  
  #calculate the odds that a gene in the MHC set has a certain TFBS
  
  MHCOdds <- apply(positiveSetPresenceAmountTFBSDf, FUN = function(x) {
    as.numeric(x[2])/totalCountsMHCSet
  }, MARGIN = 1)
  names(MHCOdds) <- positiveSetPresenceAmountTFBSDf$TFBS
  
  
  return(list(tFTableOneLine = tFTableOneLine,
              tFTableMultipleLines = tFTableMultipleLines,
              MHCGeneTable = MHCGeneTable,
              genomeOdds = genomeOdds,
              MHCOdds = MHCOdds,
              positiveSetTFBSCounts = positiveSetTFBSCounts,
              totalSetTFBSCounts = totalSetTFBSCounts
              )
        )
  
}




#function takes whole genome count data and positive set count data,
#executes fisher's exact p on all relevant TFSB to find if they are enriched
#in positive set
computeFisherstest = function(wholeGenomeTFBSCountData, positiveSetTFBSCountData) {
  
  #Get only those genes from the whole genome that have TFBS that are also found in the positive MHC set
  relevantWholeGenome <- wholeGenomeTFBSCountData[wholeGenomeTFBSCountData$TFBS %in% positiveSetTFBSCountData$TFBS,] 
  totalCountsWholeGenome <- sum(wholeGenomeTFBSCountData$Counts)
  totalCountsMHCGenes <- sum(positiveSetTFBSCountData$Counts)
  
  #listMatrices is for debug purposes, to check whether correct contingency tables are created
  listMatrices <- list()
  fisherDataFrame <- data.frame(TFBS = character(),
                                pValue=numeric(),
                                sampleEstimate=numeric(),
                                lowerConfidenceInterval=numeric(),
                                upperConfidenceInterval=numeric())
  
  #cycle over all the rows of 
  for(bindingSites in 1:nrow(positiveSetTFBSCountData)) {
    
    fisherMatrix <- matrix(c(positiveSetTFBSCountData$Counts[bindingSites],
                             totalCountsMHCGenes - positiveSetTFBSCountData$Counts[bindingSites],
                             relevantWholeGenome$Counts[bindingSites],
                             totalCountsWholeGenome - relevantWholeGenome$Counts[bindingSites]),
                           nrow = 2,
                           dimnames = list(TFBS = c(relevantWholeGenome$TFBS[bindingSites], "TotalTFBS"),
                                           Set = c("Positive set", "Whole genome")))
    fisherTestResult <- fisher.test(fisherMatrix)
    pValue = fisherTestResult["p.value"]
    lowerConfInt <- unlist(fisherTestResult["conf.int"])[1]
    upperConfInt <- unlist(fisherTestResult["conf.int"])[2]
    sampleEst <- fisherTestResult["estimate"]
    
    listMatrices <- append(listMatrices,fisherMatrix)
    addVector <- c(as.character(relevantWholeGenome$TFBS[bindingSites]),
                   pValue,
                   sampleEst,
                   lowerConfInt,
                   upperConfInt)
    names(addVector) <- c("TFBS", "pValue", "sampleEstimate",
                          "lowerConfidenceInterval", "upperConfidenceInterval")
    #add to the Df the results of the fisherTest
    fisherDataFrame <- rbind(fisherDataFrame, addVector, make.row.names = FALSE)
    
  }
  #adjust for multiple testing with Benjamini-Hochberg methodology (utilises FDR)
  fisherDataFrame$qValue <- p.adjust(fisherDataFrame$pValue, method="BH")
  return(fisherDataFrame)
  
  
  
}

#takes the dataframe with Fisher tests and sample estimates as well as whole genome data.
#returns dataframe with score per TFBS and total score of all genes in the 29 mammals data.
scoresOverRows <- function(wholeGenomeDataOneLine, fisherTests) {
  
  # find TFBS that are significantly overrepresented in positive set genes
  #assign them a score. log(sample Estimate/qValue). Log to scale,
  #sample estimate to incorporate effect size (i.e. HOW overrepresented are they in MHC genes?)
  #qValue to incorporate probability ( TFBS with p>0.05<0.10 are less sure to be correct than those with p< 0.001)
  
  informativeTFBS <- fisherTests[fisherTests$qValue <= 0.10,]
  informativeTFBS[order(informativeTFBS$qValue),]
  rownames(informativeTFBS) = seq(1:nrow(informativeTFBS))
  informativeTFBS$score <- log(informativeTFBS$sampleEstimate / informativeTFBS$qValue)
  
  
  
  scoreCompendium <- vector()
  dataFrameResults <- data.frame()
  #cycle over rows. Could be refined with an apply function
  for(rows in 1:nrow(wholeGenomeDataOneLine)) {
    
    #check whether any of the informative TFBS are present in a gene's promoter region
    currentRow <- wholeGenomeDataOneLine[rows,]
    currentRowTFs <- currentRow[2]
    characterVectorTFs <- unlist(strsplit(as.character(currentRowTFs), split = "|", fixed = TRUE))
    logicalPresence <- informativeTFBS$TFBS %in% characterVectorTFs
    currentRowEnsemblId <- currentRow["EnsemblId"]
    
    for(bindingSites in 1:length(logicalPresence)) {
      #for all informative TFBS, if they are present, add their score, otherwise, add 0
      if(logicalPresence[bindingSites] == TRUE) {
        
        valueToAdd <- informativeTFBS$score[bindingSites]
        
        
      } else if (logicalPresence[bindingSites] == FALSE) {
        
        valueToAdd <- 0
        
      }
      
      scoreCompendium <- append(scoreCompendium,valueToAdd)
      names(scoreCompendium)[bindingSites] <-  informativeTFBS$TFBS[bindingSites]
      
    }
    #set rownames as the EnsemblId of the gene from the whole genome
    dataFrameResults <- rbind(dataFrameResults, scoreCompendium)
    rownames(dataFrameResults) <- c(head(rownames(dataFrameResults),-1),currentRow["EnsemblId"])
    scoreCompendium <- vector()
    #print(nrow(dataFrameResults))
    
  }
  colnames(dataFrameResults) <- paste("Score for TFBS", informativeTFBS$TFBS)
  dataFrameResults$totalScore <- rowSums(dataFrameResults)
  dataFrameResults <- dataFrameResults[order(dataFrameResults$totalScore, decreasing = TRUE),]
  print("These are the informative TFBS:")
  print(informativeTFBS$TFBS)
  return(list(
    scoresWholeGenome = dataFrameResults,
    informativeTFBS = informativeTFBS))
}

#actual execution
dataStructureTFBS <- loadLibraryAndData(FALSE)
str(dataStructureTFBS)
dataStructureTFBS$tFTableOneLine
fisherTests <- computeFisherstest(dataStructureTFBS$totalSetTFBSCounts,dataStructureTFBS$positiveSetTFBSCounts)
str(fisherTests)
finalScoresWholeGenome <- scoresOverRows(dataStructureTFBS$tFTableOneLine[1:100,],fisherTests)
str(finalScoresWholeGenome)
head(finalScoresWholeGenome$scoresWholeGenome)



